export const COMMAND = {
  ADD: 'add',
};